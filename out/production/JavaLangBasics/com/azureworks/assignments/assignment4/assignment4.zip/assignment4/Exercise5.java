package com.azureworks.assignments.assignment4;

public class Exercise5 {
    public static void main(String[] args) {

        int sum = 0;

        for (int i =1; i<11; i++){
            sum = sum+i;
        }

        System.out.println("Sum = " + sum);
    }
}
