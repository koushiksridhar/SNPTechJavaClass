package com.azureworks.assignments.assignment4;

public class Exercise4 {
    public static void main(String[] args) {

        for (int i=0; i < 10; i++ ){
            int num = i+1;
            System.out.println("Number = " + num);
        }
    }
}
