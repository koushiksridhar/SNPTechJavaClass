package com.azureworks.assignments.assignment5;

public class Exercise4 {
    public static void main(String[] args) {
        for (int i = 0; i<10000; i++ ){
            System.out.println(10000 - i);
        }
    }
}
